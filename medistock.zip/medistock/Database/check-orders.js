const db = require('../config/db');

console.log('ORDERS:');
console.log(db.prepare('SELECT id, patient_id, name, city, total, created_at FROM orders').all());

console.log('LAST 10 SALES:');
console.log(db.prepare(
  'SELECT id, patient_id, medicine_id, qty, total, order_id, created_at FROM sales ORDER BY id DESC LIMIT 10'
).all());