const db = require('../config/db');

// Test medicines that were never sold
for (const name of ['BasavanaGowda', 'paracetamapl']) {
  const meds = db.prepare('SELECT id FROM medicines WHERE name = ?').all(name);
  for (const m of meds) {
    const sold = db.prepare('SELECT COUNT(*) AS c FROM sales WHERE medicine_id = ?').get(m.id).c;
    if (sold === 0) {
      db.prepare('DELETE FROM batches WHERE medicine_id = ?').run(m.id);
      db.prepare('DELETE FROM medicines WHERE id = ?').run(m.id);
    }
  }
}

// Very old test batches (expiry before 2020)
db.exec("DELETE FROM batches WHERE expiry_date < '2020-01-01'");

console.log('Removed test medicines and very old batches.');