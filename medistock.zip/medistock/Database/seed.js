const bcrypt = require('bcryptjs');
const db = require('../config/db');

// helper: a date n days from today, as YYYY-MM-DD
function daysFromNow(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

if (db.prepare('SELECT COUNT(*) AS c FROM users').get().c > 0) {
  console.log('Already seeded.');
  process.exit();
}

const password = bcrypt.hashSync('pass123', 10);
const addUser = db.prepare('INSERT INTO users (name, email, password, role, phone) VALUES (?, ?, ?, ?, ?)');
addUser.run('Admin', 'admin@medistock.com', password, 'admin', '');
addUser.run('Priya Pharmacist', 'pharmacist@medistock.com', password, 'pharmacist', '');
addUser.run('Chandan Cashier', 'cashier@medistock.com', password, 'cashier', '');
addUser.run('Asha Patient', 'patient@medistock.com', password, 'patient', '9876543210');

const addMed = db.prepare('INSERT INTO medicines (name, price, reorder_level) VALUES (?, ?, ?)');
addMed.run('Paracetamol 500mg', 2.5, 50);
addMed.run('Amoxicillin 250mg', 8, 20);
addMed.run('Cetirizine 10mg', 3, 30);
addMed.run('Metformin 500mg', 4, 40);

const addBatch = db.prepare('INSERT INTO batches (medicine_id, batch_no, expiry_date, qty) VALUES (?, ?, ?, ?)');
addBatch.run(1, 'PCM-001', daysFromNow(300), 200);
addBatch.run(1, 'PCM-000', daysFromNow(-10), 20); // already expired
addBatch.run(2, 'AMX-014', daysFromNow(45), 8);   // low stock and expiring soon
addBatch.run(3, 'CTZ-220', daysFromNow(500), 120);
addBatch.run(4, 'MET-310', daysFromNow(80), 60);

console.log('Done. Password for every demo user is pass123');